# Prompt para Figma — Diseño de Modal "Nueva Orden de Compra"

---

## Contexto del Proyecto

Diseña un modal para un sistema POS llamado **HermeX POS** (sistema de punto de venta para autopartes). El modal se usa para crear Órdenes de Compra a proveedores.

**Referencia funcional:** Lightspeed Retail (Purchase Orders module)
**Estilo visual:** Debe seguir el design system existente de HermeX POS (shadcn-vue + Tailwind CSS v4)

---

## Design System de Referencia

### Colores
| Token | Light | Dark | Uso |
|-------|-------|------|-----|
| `bg-card` | `#FFFFFF` | `#1A1A2E` | Fondos de cards/modals |
| `bg-muted` | `#F3F4F6` | `#16213E` | Fondos secundarios |
| `bg-background` | `#F9FAFB` | `#0F172A` | Fondo general |
| `border-border` | `#E5E7EB` | `#374151` | Bordes |
| `text-primary` | `#4F46E5` (indigo-600) | `#818CF8` (indigo-400) | Acentos principales |
| `text-gray-900` | `#111827` | `#F9FAFB` | Texto principal |
| `text-gray-500` | `#6B7280` | `#9CA3AF` | Texto secundario |
| `green-600` | `#16A34A` | `#4ADE80` | Éxito/stock |
| `red-600` | `#DC2626` | `#F87171` | Error/sin stock |
| `amber-600` | `#D97706` | `#FBBF24` | Advertencia |
| `orange-600` | `#EA580C` | `#FB923C` | Compra rápida |

### Tipografía
- **Font family:** Inter (sans-serif)
- **H1:** 32px bold (2rem)
- **H2:** 20px bold (1.25rem)
- **H3:** 18px semibold (1.125rem)
- **Body:** 14px regular (0.875rem)
- **Small:** 12px regular (0.75rem)
- **Caption:** 11px semibold uppercase (0.6875rem)
- **Mono:** JetBrains Mono para SKUs y números

### Espaciado
- Scale: 4px base (4, 8, 12, 16, 20, 24, 32, 40, 48, 64)
- Border radius: 8px (lg), 12px (xl), 16px (2xl)
- Shadows: `shadow-sm`, `shadow-lg`, `shadow-2xl`, `shadow-xl`

### Componentes Base (shadcn-vue style)
- **Inputs:** `h-10`, `rounded-lg`, `border border-gray-300`, `px-3 py-2`, `focus:ring-2 focus:ring-indigo-500`
- **Buttons Primary:** `bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-4 py-2`
- **Buttons Secondary:** `border border-gray-300 text-gray-700 hover:bg-gray-50 rounded-lg`
- **Buttons Danger:** `border border-red-300 text-red-600 hover:bg-red-50 rounded-lg`
- **Badges:** `px-2 py-1 text-xs rounded-full font-semibold`
- **Select/SearchableSelect:** Dropdown con búsqueda integrada

---

## Especificación del Modal

### Dimensiones
- **Ancho máximo:** 1120px (max-w-5xl)
- **Alto máximo:** 90vh
- **Padding interno:** 24px (px-6 py-4 en secciones)
- **Backdrop:** `bg-black/50 backdrop-blur-sm`

### Estructura General

```
┌─────────────────────────────────────────────────────────────────┐
│  HEADER (sticky, h-16, border-b)                               │
│  [Icono 📦] Título + subtítulo              [X cerrar]         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  BODY (flex-1, overflow-y-auto, p-6)                          │
│                                                                 │
│  ┌─ MÉTODO (radio toggle) ──────────────────────────────────┐ │
│  │  ◉ Manual    ○ Listado por Proveedor                      │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌─ DETALLES (collapsible section) ─────────────────────────┐ │
│  │  > Detalles  (expandible)                                 │ │
│  │  ┌─────────────────────────────────────────────────────┐ │ │
│  │  │ Proveedor: [SearchableSelect ____________ ▼]        │ │ │
│  │  │ Almacén:   [SearchableSelect ____________ ▼]        │ │ │
│  │  │ Fecha OC:  [📅 2026-04-26]  Esperada: [📅 _______]  │ │ │
│  │  │ Factura #: [_______________]                        │ │ │
│  │  │ Notas:     [___________________________________]    │ │ │
│  │  │            [___________________________________]    │ │ │
│  │  └─────────────────────────────────────────────────────┘ │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌─ AGREGAR ITEMS ──────────────────────────────────────────┐ │
│  │                                                           │ │
│  │  [MODO MANUAL ACTIVO]                                     │ │
│  │  ┌─────────────────────────────────────────────────────┐ │ │
│  │  │ 🔍 Buscar producto por nombre o SKU...  [Add item] │ │ │
│  │  │ └─ Dropdown: resultados con imagen, nombre, SKU,   │ │ │
│  │  │    marca, costo                                     │ │ │
│  │  └─────────────────────────────────────────────────────┘ │ │
│  │                                                           │
│  │  [MODO LISTADO - cuando se activa]                        │ │
│  │  ┌─────────────────────────────────────────────────────┐ │ │
│  │  │ Selecciona un proveedor para cargar su catálogo     │ │ │
│  │  │ ┌─ Filtros ──────────────────────────────────────┐ │ │ │
│  │  │ │ [All categories ▼] [All brands ▼] [Generate]   │ │ │ │
│  │  │ └────────────────────────────────────────────────┘ │ │ │
│  │  │ ┌─ Tabla de productos del proveedor ─────────────┐ │ │ │
│  │  │ │ ☑ │ SKU │ Producto │ Marca │ Stock │ Sugerido │ │ │ │
│  │  │ │ ☑ │ ... │ ...      │ ...   │ 0 🔴  │ 5        │ │ │ │
│  │  │ │ ☐ │ ... │ ...      │ ...   │ 12 🟢 │ 0        │ │ │ │
│  │  │ └────────────────────────────────────────────────┘ │ │ │
│  │  │ [Agregar seleccionados (3)]                        │ │ │
│  │  └─────────────────────────────────────────────────────┘ │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌─ TABLA DE ITEMS ─────────────────────────────────────────┐ │
│  │  Items (3)                                                │ │
│  │  ┌─────────────────────────────────────────────────────┐ │ │
│  │  │ Producto          │ Marca  │ Qty │ Und/Paq │ Costo │ │ │
│  │  ├───────────────────┼────────┼─────┼─────────┼───────┤ │ │
│  │  │ TERMINAL EXTERNO  │ 555    │ [5] │ [1]     │ $8.76 │ │ │
│  │  │ 45046-59026       │        │     │         │       │ │ │
│  │  ├───────────────────┼────────┼──────────────┼───────┤ │ │
│  │  │ BASE MOTOR HYUN   │ BOSCH  │ [2] │ [1]     │ $12.06│ │ │
│  │  │ 22311-4A100-M     │        │     │         │       │ │ │
│  │  ├───────────────────┼────────┼─────┼─────────┼───────┤ │ │
│  │  │ EMPAQUE CABEZOTE  │ JIKIU  │ [1] │ [1]     │ $6.84 │ │ │
│  │  │ 22311-4A100-AS    │        │     │         │       │ │ │
│  │  └───────────────────┴────────┴─────┴─────────┴───────┘ │ │
│  │                                         [🗑] [🗑] [🗑]   │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌─ RESUMEN FINANCIERO ─────────────────────────────────────┐ │
│  │  ┌─────────────────────────────────────────────────────┐ │ │
│  │  │ Subtotal:       $142.50                             │ │ │
│  │  │ ITBM (7%):      $9.98                               │ │ │
│  │  │ Envío:          [$0.00]                             │ │ │
│  │  │ ─────────────────────────────                       │ │ │
│  │  │ TOTAL:          $152.48                             │ │ │
│  │  └─────────────────────────────────────────────────────┘ │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│  FOOTER (sticky, h-16, border-t, bg-gray-50)                  │
│  [Cancelar]     [Guardar Borrador]     [Enviar al Proveedor]   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Componentes a Diseñar

### 1. Header del Modal
- Icono: Package (lucide) en círculo `w-10 h-10 rounded-xl bg-indigo-100`
- Título: "Nueva Orden de Compra" (20px bold)
- Subtítulo: "Selecciona método y agrega productos" (12px gray-500)
- Botón cerrar: X icon, `p-2 rounded-full hover:bg-gray-100`

### 2. Method Toggle (Radio como tabs)
- Container: `rounded-xl border border-gray-200 bg-gray-50 p-1 w-fit`
- Botón activo: `bg-white text-gray-900 shadow-sm rounded-lg px-4 py-2`
- Botón inactivo: `text-gray-500 hover:text-gray-700 rounded-lg px-4 py-2`
- Iconos: Pencil (manual), List (listado)

### 3. Collapsible Section "Detalles"
- Trigger: ChevronRight icon + "Detalles" (14px font-semibold)
- Chevron rota 90° cuando está abierto
- Grid 2 columnas para campos
- Campos:
  - **Proveedor:** SearchableSelect con búsqueda integrada
  - **Almacén:** SearchableSelect
  - **Fecha OC:** Date picker (default: hoy)
  - **Fecha Esperada:** Date picker
  - **Factura #:** Text input (placeholder: "ASD1221")
  - **Notas:** Textarea 2 rows

### 4. Search Bar (Modo Manual)
- Input con icono Search a la izquierda
- Placeholder: "Buscar producto por nombre o SKU..."
- Botón "Add item" a la derecha (indigo-600)
- Dropdown de resultados:
  - Cada resultado: imagen thumbnail (40x40), nombre, SKU, marca, costo
  - Hover: `bg-gray-50`
  - Click: agrega a tabla de items

### 5. Product List (Modo Listado)
- Header: "Selecciona un proveedor para cargar su catálogo"
- Filtros: 2 dropdowns (categorías, marcas) + botón "Generar"
- Tabla con checkboxes:
  - Columnas: ☑, SKU, Producto, Marca, Stock (badge color), Sugerido
  - Stock badges: 🔴 rojo (0), 🟡 ámbar (1-5), 🟢 verde (>5)
  - Botón inferior: "Agregar seleccionados (3)" (indigo-600)

### 6. Items Table
- Header: "Items (3)" con icono Package
- Columnas:
  - **Producto:** Nombre + SKU (font-mono) debajo
  - **Marca:** Badge con nombre de marca
  - **Qty:** Number input `w-16 text-right`
  - **Und/Paq:** Number input `w-16 text-right`
  - **Costo Unit.:** Number input `w-24 text-right` con prefijo $
  - **Subtotal:** Calculado, read-only, font-semibold
  - **Acciones:** Botón eliminar (Trash2 icon, hover rojo)
- Rows: `hover:bg-gray-50 dark:hover:bg-muted/50`
- Empty state: Icono Package grande + "Busca y agrega productos al pedido"

### 7. Financial Summary
- Container: `bg-gray-50 dark:bg-muted rounded-lg p-4`
- Layout: Grid 2 columnas en mobile, 4 en desktop
- Filas:
  - Subtotal: `$142.50` (gray-600)
  - ITBM (7%): `$9.98` (gray-600)
  - Envío: Input editable `$0.00`
  - **TOTAL:** `$152.48` (24px bold, indigo-600)

### 8. Footer
- Background: `bg-gray-50 dark:bg-muted/20 border-t`
- Botones alineados a la derecha con gap-3:
  - **Cancelar:** Secondary style, gray border
  - **Guardar Borrador:** Primary style, indigo-600
  - **Enviar al Proveedor:** Primary style, green-600 (cuando hay items)

---

## Estados a Diseñar

### Loading States
- Skeleton loaders para tabla de items
- Spinner en botón "Buscar" durante búsqueda
- Spinner en botón "Enviar" durante submit

### Empty States
- Tabla de items vacía: Icono Package (48px, gray-300) + texto "Busca y agrega productos al pedido"
- Sin resultados de búsqueda: Icono Search + "No se encontraron productos"
- Modo listado sin proveedor seleccionado: Icono Building2 + "Selecciona un proveedor para ver su catálogo"

### Error States
- Banner rojo en top del modal: `bg-red-50 border border-red-200 rounded-lg p-3`
- Icono AlertCircle + mensaje de error
- Input con borde rojo cuando hay error de validación

### Disabled States
- Botones con `opacity-50 cursor-not-allowed`
- Inputs con `bg-gray-100 text-gray-400`

### Hover States
- Rows de tabla: `bg-gray-50`
- Botones: cambio de color de fondo
- Iconos de acción: cambio a color primario

---

## Responsive Breakpoints

### Desktop (>1024px)
- Modal: max-w-5xl, centrado
- Detalles: Grid 2 columnas
- Resumen financiero: Grid 4 columnas

### Tablet (768px-1024px)
- Modal: max-w-3xl
- Detalles: Grid 1 columna
- Resumen financiero: Grid 2 columnas

### Mobile (<768px)
- Modal: full width con padding
- Detalles: Grid 1 columna
- Resumen financiero: Grid 1 columna
- Tabla: scroll horizontal

---

## Dark Mode

Todos los componentes deben tener variante dark:
- `bg-white` → `bg-card` (#1A1A2E)
- `bg-gray-50` → `bg-muted` (#16213E)
- `text-gray-900` → `text-white`
- `text-gray-500` → `text-gray-400`
- `border-gray-200` → `border-border` (#374151)
- `border-gray-300` → `border-border`
- `bg-indigo-100` → `bg-indigo-500/20`
- `text-indigo-600` → `text-indigo-400`

---

## Entregables Esperados en Figma

1. **Frame principal:** Modal completo en desktop (1120px)
2. **Variantes de método:** Manual activo vs Listado activo
3. **Estados de la tabla:** Con items, vacía, con 1 item
4. **Dropdown de búsqueda:** Con resultados hover
5. **Collapsible:** Abierto y cerrado
6. **Responsive:** Tablet y mobile frames
7. **Dark mode:** Variante completa del modal
8. **Componentes reutilizables:**
   - SearchableSelect
   - NumberInput (con prefijo $)
   - DatePicker
   - MethodToggle
   - FinancialSummary
   - ItemRow
   - StockBadge
9. **Design tokens:** Colors, Typography, Spacing, Shadows, Radius
10. **Auto-layout:** Todos los frames con auto-layout configurado

---

## Notas de Implementación

- Usar **Auto Layout** en todos los frames para facilitar desarrollo
- Componentes deben ser **variants** con propiedades booleanas (isOpen, isLoading, etc.)
- Usar **constraints** para responsive behavior
- Crear **styles** para typography y colors que matchen los tokens de Tailwind
- Incluir **interactive prototypes** para:
  - Toggle entre Manual/Listado
  - Expandir/colapsar Detalles
  - Agregar item desde búsqueda
  - Eliminar item de tabla
  - Cambiar cantidad/costo en inputs

---

¿Quieres que ajuste algo del prompt antes de que lo uses en Figma?