import { useState } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import * as Collapsible from '@radix-ui/react-collapsible';
import { Package, X, Pencil, List, ChevronRight, Search, Building2, Trash2, Calendar, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';

interface Product {
  id: string;
  name: string;
  sku: string;
  brand: string;
  cost: number;
  image?: string;
}

interface OrderItem extends Product {
  quantity: number;
  unitsPerPackage: number;
}

interface Supplier {
  id: string;
  name: string;
}

interface Warehouse {
  id: string;
  name: string;
}

export default function PurchaseOrderModal() {
  const [open, setOpen] = useState(true);
  const [method, setMethod] = useState<'manual' | 'listing'>('manual');
  const [detailsOpen, setDetailsOpen] = useState(true);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);

  // Form state
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [selectedWarehouse, setSelectedWarehouse] = useState<Warehouse | null>(null);
  const [orderDate] = useState(new Date());
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [shipping, setShipping] = useState(0);

  // Mock data
  const mockProducts: Product[] = [
    { id: '1', name: 'TERMINAL EXTERNO', sku: '45046-59026', brand: '555', cost: 8.76 },
    { id: '2', name: 'BASE MOTOR HYUNDAI', sku: '22311-4A100-M', brand: 'BOSCH', cost: 12.06 },
    { id: '3', name: 'EMPAQUE CABEZOTE', sku: '22311-4A100-AS', brand: 'JIKIU', cost: 6.84 },
    { id: '4', name: 'FILTRO DE ACEITE', sku: 'OF-123456', brand: 'MANN', cost: 15.50 },
    { id: '5', name: 'PASTILLAS DE FRENO', sku: 'BP-789012', brand: 'BREMBO', cost: 45.00 },
  ];

  const mockSuppliers: Supplier[] = [
    { id: '1', name: 'AutoPartes del Norte' },
    { id: '2', name: 'Distribuidora Central' },
    { id: '3', name: 'Importadora Global' },
  ];

  const mockWarehouses: Warehouse[] = [
    { id: '1', name: 'Almacén Principal' },
    { id: '2', name: 'Almacén Norte' },
    { id: '3', name: 'Almacén Sur' },
  ];

  const searchResults = searchQuery.length > 0
    ? mockProducts.filter(p =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.sku.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const addItem = (product: Product) => {
    const existingItem = items.find(item => item.id === product.id);
    if (existingItem) {
      setItems(items.map(item =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setItems([...items, { ...product, quantity: 1, unitsPerPackage: 1 }]);
    }
    setSearchQuery('');
    setShowSearchResults(false);
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const updateItem = (id: string, field: 'quantity' | 'unitsPerPackage' | 'cost', value: number) => {
    setItems(items.map(item =>
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  const subtotal = items.reduce((sum, item) => sum + (item.cost * item.quantity * item.unitsPerPackage), 0);
  const tax = subtotal * 0.07;
  const total = subtotal + tax + shipping;

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50" />
        <Dialog.Content className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-5xl max-h-[90vh] bg-white dark:bg-card rounded-2xl shadow-2xl z-50 flex flex-col">
          {/* Header */}
          <div className="h-16 px-6 flex items-center justify-between border-b border-border">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-500/20 flex items-center justify-center">
                <Package className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              </div>
              <div>
                <Dialog.Title className="text-xl font-bold text-gray-900 dark:text-white">
                  Nueva Orden de Compra
                </Dialog.Title>
                <Dialog.Description className="text-xs text-gray-500 dark:text-gray-400">
                  Selecciona método y agrega productos
                </Dialog.Description>
              </div>
            </div>
            <Dialog.Close className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-muted transition-colors">
              <X className="w-5 h-5 text-gray-500" />
            </Dialog.Close>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Method Toggle */}
            <div className="rounded-xl border border-gray-200 dark:border-border bg-gray-50 dark:bg-muted p-1 w-fit">
              <div className="flex gap-1">
                <button
                  onClick={() => setMethod('manual')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    method === 'manual'
                      ? 'bg-white dark:bg-card text-gray-900 dark:text-white shadow-sm'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  <Pencil className="w-4 h-4" />
                  <span className="text-sm font-medium">Manual</span>
                </button>
                <button
                  onClick={() => setMethod('listing')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    method === 'listing'
                      ? 'bg-white dark:bg-card text-gray-900 dark:text-white shadow-sm'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  <List className="w-4 h-4" />
                  <span className="text-sm font-medium">Listado por Proveedor</span>
                </button>
              </div>
            </div>

            {/* Details Section */}
            <Collapsible.Root open={detailsOpen} onOpenChange={setDetailsOpen}>
              <Collapsible.Trigger className="flex items-center gap-2 text-sm font-semibold text-gray-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                <ChevronRight className={`w-4 h-4 transition-transform ${detailsOpen ? 'rotate-90' : ''}`} />
                Detalles
              </Collapsible.Trigger>
              <Collapsible.Content className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-lg border border-gray-200 dark:border-border bg-gray-50 dark:bg-muted">
                  {/* Supplier */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Proveedor</label>
                    <select
                      value={selectedSupplier?.id || ''}
                      onChange={(e) => setSelectedSupplier(mockSuppliers.find(s => s.id === e.target.value) || null)}
                      className="w-full h-10 rounded-lg border border-gray-300 dark:border-border bg-white dark:bg-card px-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    >
                      <option value="">Seleccionar proveedor...</option>
                      {mockSuppliers.map(supplier => (
                        <option key={supplier.id} value={supplier.id}>{supplier.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Warehouse */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Almacén</label>
                    <select
                      value={selectedWarehouse?.id || ''}
                      onChange={(e) => setSelectedWarehouse(mockWarehouses.find(w => w.id === e.target.value) || null)}
                      className="w-full h-10 rounded-lg border border-gray-300 dark:border-border bg-white dark:bg-card px-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    >
                      <option value="">Seleccionar almacén...</option>
                      {mockWarehouses.map(warehouse => (
                        <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Order Date */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Fecha OC</label>
                    <div className="flex items-center gap-2 h-10 rounded-lg border border-gray-300 dark:border-border bg-white dark:bg-card px-3">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">{format(orderDate, 'yyyy-MM-dd')}</span>
                    </div>
                  </div>

                  {/* Invoice Number */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Factura #</label>
                    <input
                      type="text"
                      value={invoiceNumber}
                      onChange={(e) => setInvoiceNumber(e.target.value)}
                      placeholder="ASD1221"
                      className="w-full h-10 rounded-lg border border-gray-300 dark:border-border bg-white dark:bg-card px-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  {/* Notes */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Notas</label>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={2}
                      className="w-full rounded-lg border border-gray-300 dark:border-border bg-white dark:bg-card px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                    />
                  </div>
                </div>
              </Collapsible.Content>
            </Collapsible.Root>

            {/* Add Items Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Agregar Items</h3>

              {method === 'manual' ? (
                <div className="relative">
                  <div className="flex gap-2">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => {
                          setSearchQuery(e.target.value);
                          setShowSearchResults(true);
                        }}
                        onFocus={() => setShowSearchResults(true)}
                        placeholder="Buscar producto por nombre o SKU..."
                        className="w-full h-10 pl-10 pr-3 rounded-lg border border-gray-300 dark:border-border bg-white dark:bg-card text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  {/* Search Results Dropdown */}
                  {showSearchResults && searchResults.length > 0 && (
                    <div className="absolute z-10 w-full mt-2 bg-white dark:bg-card border border-gray-200 dark:border-border rounded-lg shadow-lg max-h-64 overflow-y-auto">
                      {searchResults.map(product => (
                        <button
                          key={product.id}
                          onClick={() => addItem(product)}
                          className="w-full flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-muted transition-colors text-left"
                        >
                          <div className="w-10 h-10 rounded bg-gray-100 dark:bg-muted flex items-center justify-center">
                            <Package className="w-5 h-5 text-gray-400" />
                          </div>
                          <div className="flex-1">
                            <div className="text-sm font-medium text-gray-900 dark:text-white">{product.name}</div>
                            <div className="text-xs text-gray-500 dark:text-gray-400 font-mono">{product.sku}</div>
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{product.brand}</div>
                          <div className="text-sm font-semibold text-gray-900 dark:text-white">${product.cost.toFixed(2)}</div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-6 rounded-lg border border-gray-200 dark:border-border bg-gray-50 dark:bg-muted text-center">
                  <Building2 className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Selecciona un proveedor para ver su catálogo
                  </p>
                </div>
              )}
            </div>

            {/* Items Table */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-gray-500" />
                <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Items ({items.length})
                </h3>
              </div>

              {items.length > 0 ? (
                <div className="rounded-lg border border-gray-200 dark:border-border overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 dark:bg-muted">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300">Producto</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300">Marca</th>
                          <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 dark:text-gray-300">Qty</th>
                          <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 dark:text-gray-300">Und/Paq</th>
                          <th className="px-4 py-3 text-right text-xs font-semibold text-gray-700 dark:text-gray-300">Costo</th>
                          <th className="px-4 py-3 text-right text-xs font-semibold text-gray-700 dark:text-gray-300">Subtotal</th>
                          <th className="px-4 py-3"></th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-card divide-y divide-gray-200 dark:divide-border">
                        {items.map(item => (
                          <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-muted/50 transition-colors">
                            <td className="px-4 py-3">
                              <div>
                                <div className="text-sm font-medium text-gray-900 dark:text-white">{item.name}</div>
                                <div className="text-xs text-gray-500 dark:text-gray-400 font-mono">{item.sku}</div>
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 dark:bg-muted text-gray-700 dark:text-gray-300">
                                {item.brand}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <input
                                type="number"
                                min="1"
                                value={item.quantity}
                                onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 1)}
                                className="w-16 h-8 px-2 text-right text-sm rounded border border-gray-300 dark:border-border bg-white dark:bg-card focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                              />
                            </td>
                            <td className="px-4 py-3">
                              <input
                                type="number"
                                min="1"
                                value={item.unitsPerPackage}
                                onChange={(e) => updateItem(item.id, 'unitsPerPackage', parseInt(e.target.value) || 1)}
                                className="w-16 h-8 px-2 text-right text-sm rounded border border-gray-300 dark:border-border bg-white dark:bg-card focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                              />
                            </td>
                            <td className="px-4 py-3">
                              <input
                                type="number"
                                min="0"
                                step="0.01"
                                value={item.cost}
                                onChange={(e) => updateItem(item.id, 'cost', parseFloat(e.target.value) || 0)}
                                className="w-24 h-8 px-2 text-right text-sm rounded border border-gray-300 dark:border-border bg-white dark:bg-card focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                              />
                            </td>
                            <td className="px-4 py-3 text-right text-sm font-semibold text-gray-900 dark:text-white">
                              ${(item.cost * item.quantity * item.unitsPerPackage).toFixed(2)}
                            </td>
                            <td className="px-4 py-3">
                              <button
                                onClick={() => removeItem(item.id)}
                                className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="py-12 text-center border border-gray-200 dark:border-border rounded-lg">
                  <Package className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Busca y agrega productos al pedido
                  </p>
                </div>
              )}
            </div>

            {/* Financial Summary */}
            {items.length > 0 && (
              <div className="bg-gray-50 dark:bg-muted rounded-lg p-6">
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Subtotal:</span>
                    <span className="font-medium text-gray-900 dark:text-white">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">ITBM (7%):</span>
                    <span className="font-medium text-gray-900 dark:text-white">${tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Envío:</span>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={shipping}
                      onChange={(e) => setShipping(parseFloat(e.target.value) || 0)}
                      className="w-24 h-8 px-2 text-right text-sm rounded border border-gray-300 dark:border-border bg-white dark:bg-card focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                  <div className="pt-3 border-t border-gray-200 dark:border-border">
                    <div className="flex justify-between">
                      <span className="text-lg font-bold text-gray-900 dark:text-white">TOTAL:</span>
                      <span className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">${total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="h-16 px-6 flex items-center justify-end gap-3 border-t border-border bg-gray-50 dark:bg-muted/20">
            <button
              onClick={() => setOpen(false)}
              className="px-4 py-2 rounded-lg border border-gray-300 dark:border-border text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-muted transition-colors text-sm font-medium"
            >
              Cancelar
            </button>
            <button
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition-colors text-sm font-medium"
            >
              Guardar Borrador
            </button>
            <button
              disabled={items.length === 0}
              className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Enviar al Proveedor
            </button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
