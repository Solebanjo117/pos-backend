import PurchaseOrderModal from './components/PurchaseOrderModal';

export default function App() {
  return (
    <div className="size-full flex items-center justify-center bg-background">
      <PurchaseOrderModal />
    </div>
  );
}