
  # Crear desde archivo txt

  This is a code bundle for Crear desde archivo txt. The original project is available at https://www.figma.com/design/xBh1ffc0YysVa36O0Eg6c4/Crear-desde-archivo-txt.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  