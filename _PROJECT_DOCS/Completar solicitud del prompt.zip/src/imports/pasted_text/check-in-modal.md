# Prompt para Figma — Diseño de Modal "Check In" (Recepción de Mercancía)

---

## Contexto del Proyecto

Diseña un modal para el sistema POS **HermeX POS** (autopartes) que permite hacer **Check In** (recepción de mercancía) de una Orden de Compra. El modal reemplaza la página actual `PurchaseOrders/Receive.vue` y debe ser más visual e intuitivo.

**Referencia funcional:** Lightspeed Retail (Check In module) + flujo actual de HermeX POS
**Estilo visual:** shadcn-vue + Tailwind CSS v4 (mismo design system del proyecto)

---

## Design System (mismo que el proyecto)

### Colores
| Token | Light | Dark | Uso |
|-------|-------|------|-----|
| `bg-card` | `#FFFFFF` | `#1A1A2E` | Fondos de cards/modals |
| `bg-muted` | `#F3F4F6` | `#16213E` | Fondos secundarios |
| `bg-background` | `#F9FAFB` | `#0F172A` | Fondo general |
| `border-border` | `#E5E7EB` | `#374151` | Bordes |
| `indigo-600` | `#4F46E5` | `#818CF8` | Acentos principales |
| `text-gray-900` | `#111827` | `#F9FAFB` | Texto principal |
| `text-gray-500` | `#6B7280` | `#9CA3AF` | Texto secundario |

### Colores de Estado (CRÍTICO para este modal)
| Estado | Color | Light BG | Light Text | Dark BG | Dark Text | Significado |
|--------|-------|----------|------------|---------|-----------|-------------|
| **Sin verificar** | Gray | `bg-gray-100` | `text-gray-600` | `bg-gray-800` | `text-gray-400` | Item aún no recibido |
| **OK** | Green | `bg-green-100` | `text-green-800` | `bg-green-900/30` | `text-green-400` | Recibido = Pedido exacto |
| **Excedente** | Yellow/Amber | `bg-amber-100` | `text-amber-800` | `bg-amber-900/30` | `text-amber-400` | Recibido > Pedido |
| **Falta** | Red | `bg-red-100` | `text-red-800` | `bg-red-900/30` | `text-red-400` | Recibido < Pedido |

### Tipografía
- **Font family:** Inter
- **H1:** 24px bold
- **H2:** 18px semibold
- **Body:** 14px regular
- **Small:** 12px regular
- **Mono:** JetBrains Mono para SKUs y números

### Espaciado y Radius
- Scale: 4px base
- Border radius: 8px (lg), 12px (xl), 16px (2xl)
- Shadows: `shadow-sm`, `shadow-lg`, `shadow-2xl`

---

## Especificación del Modal

### Dimensiones
- **Ancho máximo:** 960px (max-w-4xl)
- **Alto máximo:** 85vh
- **Padding interno:** 24px
- **Backdrop:** `bg-black/50 backdrop-blur-sm`

### Estructura General

```
┌──────────────────────────────────────────────────────────────────┐
│  HEADER (sticky, h-16, border-b, bg-gray-50)                    │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ [Icono 📦] Check In — PO-20260426-0001        [X cerrar]  │ │
│  │ L&J AUTOPARTES LJ · 5 items · 3 pendientes                │ │
│  └────────────────────────────────────────────────────────────┘ │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  BODY (flex-1, overflow-y-auto, p-6)                           │
│                                                                  │
│  ┌─ ALERTA POS (si aplica) ──────────────────────────────────┐ │
│  │  ⚠️ Esta OC viene desde POS con stock preaplicado.        │ │
│  │  No volverá a sumar inventario por esa base (3 paq.).     │ │
│  │  Solo se recibirá la diferencia si aumentas cantidades.    │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌─ RESUMEN RÁPIDO ──────────────────────────────────────────┐ │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │ │
│  │  │  Total   │ │  OK      │ │  Falta   │ │ Excedente│     │ │
│  │  │    5     │ │    2     │ │    1     │ │    0     │     │ │
│  │  │  items   │ │  🟢      │ │  🔴      │ │  🟡      │     │ │
│  │  └──────────┘ └────────── └──────────┘ ──────────┘     │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌─ TABLA DE ITEMS ──────────────────────────────────────────┐ │
│  │  ┌──────────────────────────────────────────────────────┐ │ │
│  │  │ ESTADO │ Producto        │ Pedido │ Recibido │ Recibir│ │ │
│  │  ├────────┼─────────────────┼────────┼──────────────────┤ │ │
│  │  │  🟢 OK │ TERMINAL EXT.   │   5    │    5     │   0    │ │ │
│  │  │        │ 45046-59026     │  paq.  │   paq.   │  paq.  │ │ │
│  │  │        │ [555]           │        │          │        │ │ │
│  │  ├────────┼─────────────────┼────────┼──────────────────┤ │ │
│  │  │ 🔴Falta│ BASE MOTOR HYUN │   3    │    1     │  [2]   │ │ │
│  │  │        │ 22311-4A100-M   │  paq.  │   paq.   │  paq.  │ │ │
│  │  │        │ [BOSCH]         │        │          │        │ │ │
│  │  │        │ POS: 1 paq.     │        │          │        │ │ │
│  │  ├────────┼─────────────────┼────────┼──────────┼────────┤ │ │
│  │  │ 🟡Exc. │ EMPAQUE CABEZ.  │   2    │    3     │   0    │ │ │
│  │  │        │ 22311-4A100-AS  │  paq.  │   paq.   │  paq.  │ │ │
│  │  │        │ [JIKIU]         │        │          │        │ │ │
│  │  ├────────┼─────────────────┼────────┼──────────┼────────┤ │ │
│  │  │ ⚪Pend.│ BALINERA RUEDA  │   4    │    0     │  [4]   │ │ │
│  │  │        │ 51720-1W000     │  paq.  │   paq.   │  paq.  │ │ │
│  │  │        │ [555]           │        │          │        │ │ │
│  │  ├────────┼─────────────────┼────────┼──────────┼────────┤ │ │
│  │  │ ⚪Pend.│ ACEITE MOTOR    │   10   │    0     │ [10]   │ │ │
│  │  │        │ ACE-0001        │  paq.  │   paq.   │  paq.  │ │ │
│  │  │        │ [GENÉRICA]      │        │          │        │ │ │
│  │  └────────┴─────────────────┴────────┴──────────────────┘ │ │
│  │                                                            │ │
│  │  Leyenda: 🟢 OK = Recibido completo · 🔴 Falta = Pendiente│ │
│  │           🟡 Excedente = Sobrante · ⚪ Pendiente = Sin recibir│ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌─ RESUMEN DE RECEPCIÓN ────────────────────────────────────┐ │
│  │  ┌──────────────────────────────────────────────────────┐ │ │
│  │  │ Items a recibir: 3                                   │ │ │
│  │  │ Paquetes totales a recibir: 16                       │ │ │
│  │  │ Unidades totales a recibir: 16 (×1 und/paq)          │ │ │
│  │  └──────────────────────────────────────────────────────┘ │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                  │
├──────────────────────────────────────────────────────────────────┤
│  FOOTER (sticky, h-16, border-t, bg-gray-50)                   │
│  [Cancelar]     [Confirmar Recepción (3 items)]                 │
└──────────────────────────────────────────────────────────────────┘
```

---

## Componentes a Diseñar

### 1. Header del Modal
- Icono: PackageCheck (lucide) en círculo `w-10 h-10 rounded-xl bg-green-100 dark:bg-green-500/20`
- Título: "Check In" (20px bold)
- Subtítulo: PO number + nombre proveedor + conteo de items
- Botón cerrar: X icon, `p-2 rounded-full hover:bg-gray-100`
- Background: `bg-gray-50 dark:bg-muted/20`

### 2. Alerta POS (condicional)
- Container: `bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-lg p-4`
- Icono: AlertTriangle (amber)
- Texto: Explicación de stock preaplicado desde POS
- Solo aparece si la OC tiene `pre_stock_applied_qty > 0`

### 3. Resumen Rápido (Stats Cards)
- Grid 4 columnas
- Cada card:
  - Número grande (32px bold)
  - Label pequeño (12px gray-500)
  - Icono/emoji de estado
  - Border radius: 12px
  - Colores por estado:
    - Total: `bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200`
    - OK: `bg-green-50 dark:bg-green-900/20 border-green-200`
    - Falta: `bg-red-50 dark:bg-red-900/20 border-red-200`
    - Excedente: `bg-amber-50 dark:bg-amber-900/20 border-amber-200`

### 4. Tabla de Items (COMPONENTE PRINCIPAL)

#### Columnas:
| Columna | Ancho | Contenido |
|---------|-------|-----------|
| **Estado** | 80px | Badge circular con color + label corto |
| **Producto** | flex | Nombre (14px bold) + SKU (12px mono) + Marca (badge) + nota POS si aplica |
| **Pedido** | 100px | Número + "paq." (derecha) |
| **Recibido** | 100px | Número + "paq." (derecha, color según estado) |
| **Recibir** | 120px | Input numérico con valor default = pending_quantity |

#### Fila de Estado (badge):
- **🟢 OK:** `bg-green-100 text-green-800 rounded-full px-2 py-1 text-xs font-semibold`
  - Label: "OK"
- **🔴 Falta:** `bg-red-100 text-red-800 rounded-full px-2 py-1 text-xs font-semibold`
  - Label: "Falta"
- **🟡 Excedente:** `bg-amber-100 text-amber-800 rounded-full px-2 py-1 text-xs font-semibold`
  - Label: "Exc."
- **⚪ Pendiente:** `bg-gray-100 text-gray-600 rounded-full px-2 py-1 text-xs font-semibold`
  - Label: "Pend."

#### Fila de Producto:
```
TERMINAL EXTERNO              ← 14px font-medium text-gray-900
45046-59026                   ← 12px font-mono text-gray-500
[555]                         ← badge small con nombre de marca
POS: 1 paq. preaplicado       ← 11px text-amber-600 (solo si aplica)
```

#### Input "Recibir":
- Default value: `pending_quantity` (lo que falta por recibir)
- Min: 0
- Max: `pending_quantity` (no permitir recibir más de lo pendiente)
- Style: `w-20 text-right px-2 py-1 border border-gray-300 rounded bg-white`
- Cuando el usuario cambia el valor, el estado de la fila se actualiza en tiempo real:
  - Si `quantity_received == quantity_ordered` → 🟢 OK
  - Si `quantity_received < quantity_ordered` → 🔴 Falta
  - Si `quantity_received > quantity_ordered` → 🟡 Excedente
  - Si `quantity_received == 0` y `pending_quantity > 0` → ⚪ Pendiente

#### Fila completada (ya recibida anteriormente):
- Background: `bg-green-50/50 dark:bg-green-900/10`
- Input "Recibir" disabled con valor 0
- Badge: 🟢 OK
- Texto "Ya recibido" en lugar del input

### 5. Leyenda
- Texto pequeño debajo de la tabla
- `text-xs text-gray-500`
- Iconos con labels explicativos

### 6. Resumen de Recepción
- Container: `bg-gray-50 dark:bg-muted rounded-lg p-4`
- 3 líneas de info:
  - Items a recibir: X
  - Paquetes totales: X
  - Unidades totales: X
- Números en font-semibold

### 7. Footer
- Background: `bg-gray-50 dark:bg-muted/20 border-t`
- Botones:
  - **Cancelar:** Secondary style
  - **Confirmar Recepción:** Green-600, con conteo dinámico: "Confirmar Recepción (3 items)"
  - Disabled si no hay items con quantity_received > 0

---

## Lógica de Estados (para el prototipo interactivo)

### Reglas de color por fila:

```
IF quantity_received == 0 AND previously_received == 0:
  → ⚪ Pendiente (gray)

IF quantity_received == 0 AND previously_received > 0:
  → 🟢 OK (green) - ya fue recibido antes

IF quantity_received > 0 AND quantity_received < pending_quantity:
  → 🔴 Falta (red) - parcial

IF quantity_received == pending_quantity:
  → 🟢 OK (green) - completo

IF quantity_received > pending_quantity:
  → 🟡 Excedente (yellow) - sobró
```

### Computed values:
```
pending_quantity = quantity_ordered - previously_received - pre_applied_qty
quantity_received = input del usuario
total_received = previously_received + quantity_received
status = calcular según reglas arriba
```

---

## Estados a Diseñar

### 1. Estado Inicial (al abrir el modal)
- Todos los inputs "Recibir" tienen el valor de `pending_quantity`
- Estados calculados automáticamente
- Resumen actualizado

### 2. Estado con todos los items recibidos
- Todos los badges son 🟢 OK
- Inputs "Recibir" en 0 o disabled
- Botón "Confirmar" habilitado
- Stats: OK = total, Falta = 0, Excedente = 0

### 3. Estado con recepción parcial
- Algunos 🟢 OK, algunos 🔴 Falta
- Inputs con valores mixtos
- Stats reflejan el conteo real

### 4. Estado con excedente
- Al menos un item con quantity_received > pending_quantity
- Badge 🟡 Excedente en esa fila
- Stats: Excedente > 0

### 5. Loading State
- Skeleton rows en la tabla
- Spinner en botón "Confirmar"

### 6. Empty State
- Si todos los items ya fueron recibidos:
  - Icono PackageCheck (48px, green)
  - Texto: "Todos los items ya han sido recibidos"
  - Solo botón "Cerrar"

### 7. Error State
- Banner rojo en top del modal
- Icono AlertCircle + mensaje

---

## Interacciones (Prototipo)

### 1. Cambiar cantidad en input "Recibir"
- Al escribir, el badge de estado cambia en tiempo real
- El resumen de stats se actualiza
- El botón "Confirmar" actualiza el conteo

### 2. Click en "Confirmar Recepción"
- Loading state en botón
- Success: cierra modal y navega a PO detail
- Error: muestra banner rojo

### 3. Click en "Cancelar"
- Cierra modal sin cambios
- Navega de vuelta a PO detail

### 4. Scroll en tabla
- Header de tabla sticky
- Footer sticky
- Body scrollable

---

## Responsive Breakpoints

### Desktop (>1024px)
- Modal: max-w-4xl
- Stats: Grid 4 columnas
- Tabla: todas las columnas visibles

### Tablet (768px-1024px)
- Modal: max-w-3xl
- Stats: Grid 2 columnas
- Tabla: scroll horizontal

### Mobile (<768px)
- Modal: full width
- Stats: Grid 2 columnas
- Tabla: scroll horizontal, columnas comprimidas

---

## Dark Mode

Mismas reglas que el design system:
- `bg-white` → `bg-card`
- `bg-gray-50` → `bg-muted`
- `text-gray-900` → `text-white`
- `text-gray-500` → `text-gray-400`
- `border-gray-200` → `border-border`
- Badges de estado: usar variantes dark (`bg-green-900/30 text-green-400`, etc.)

---

## Entregables Esperados en Figma

1. **Frame principal:** Modal completo en desktop (960px)
2. **Variantes de estado:**
   - Inicial (todos pendientes)
   - Parcial (mixto)
   - Completo (todo OK)
   - Con excedente
   - Empty (todo ya recibido)
3. **Componentes reutilizables:**
   - StatusBadge (4 variantes: OK, Falta, Excedente, Pendiente)
   - StatsCard (4 variantes de color)
   - ItemRow (con input editable)
   - ItemRowCompleted (read-only)
   - POSAlertBanner
   - SummaryCard
4. **Design tokens:** Colors (incluyendo los 4 estados), Typography, Spacing
5. **Auto-layout:** Todos los frames con auto-layout
6. **Interactive prototype:**
   - Cambiar cantidad → actualiza estado
   - Click Confirmar → loading → success
   - Click Cancelar → cierra modal

---

## Notas de Implementación

- Usar **Auto Layout** en todos los frames
- Los **StatusBadge** deben ser variants con propiedad `status: "ok" | "falta" | "excedente" | "pendiente"`
- Los **ItemRow** deben tener propiedad `isCompleted: boolean` para variante read-only
- Incluir **interactive prototypes** para la lógica de cambio de estado en tiempo real
- Los inputs numéricos deben tener **constraints** para min/max
- El botón "Confirmar" debe mostrar **conteo dinámico** de items a recibir

---

¿Quieres que ajuste algo del prompt antes de usarlo en Figma?