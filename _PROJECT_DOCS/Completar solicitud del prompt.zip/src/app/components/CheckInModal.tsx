import { useState, useMemo } from 'react';
import { PackageCheck, X, AlertTriangle, AlertCircle } from 'lucide-react';
import * as Dialog from '@radix-ui/react-dialog';
import * as VisuallyHidden from '@radix-ui/react-visually-hidden';

type ItemStatus = 'pending' | 'ok' | 'partial' | 'excess';

interface PurchaseOrderItem {
  id: string;
  productName: string;
  sku: string;
  brand: string;
  quantityOrdered: number;
  previouslyReceived: number;
  preAppliedQty: number;
  unit: string;
}

interface CheckInModalProps {
  open: boolean;
  onClose: () => void;
  purchaseOrder: {
    id: string;
    number: string;
    supplier: string;
    location: string;
    issueDate: string;
    expectedArrivalDate: string;
    items: PurchaseOrderItem[];
  };
}

export function CheckInModal({ open, onClose, purchaseOrder }: CheckInModalProps) {
  const [receivedQuantities, setReceivedQuantities] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    purchaseOrder.items.forEach(item => {
      const pending = item.quantityOrdered - item.previouslyReceived - item.preAppliedQty;
      initial[item.id] = Math.max(0, pending);
    });
    return initial;
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleQuantityChange = (itemId: string, value: string) => {
    const numValue = parseInt(value) || 0;
    setReceivedQuantities(prev => ({
      ...prev,
      [itemId]: Math.max(0, numValue)
    }));
  };

  const handleMassCheckIn = () => {
    const massReceived: Record<string, number> = {};
    purchaseOrder.items.forEach(item => {
      const pending = item.quantityOrdered - item.previouslyReceived - item.preAppliedQty;
      massReceived[item.id] = Math.max(0, pending);
    });
    setReceivedQuantities(massReceived);
  };

  const getItemStatus = (item: PurchaseOrderItem): ItemStatus => {
    const received = receivedQuantities[item.id] || 0;
    const pending = item.quantityOrdered - item.previouslyReceived - item.preAppliedQty;

    if (received === 0 && item.previouslyReceived === 0) return 'pending';
    if (received === 0 && item.previouslyReceived > 0) return 'ok';
    if (received < pending) return 'partial';
    if (received === pending) return 'ok';
    return 'excess';
  };

  const stats = useMemo(() => {
    const itemsWithStatus = purchaseOrder.items.map(item => ({
      item,
      status: getItemStatus(item)
    }));

    return {
      total: purchaseOrder.items.length,
      ok: itemsWithStatus.filter(({ status }) => status === 'ok').length,
      partial: itemsWithStatus.filter(({ status }) => status === 'partial').length,
      excess: itemsWithStatus.filter(({ status }) => status === 'excess').length,
      pending: itemsWithStatus.filter(({ status }) => status === 'pending').length
    };
  }, [purchaseOrder.items, receivedQuantities]);

  const summary = useMemo(() => {
    const itemsToReceive = purchaseOrder.items.filter(item => (receivedQuantities[item.id] || 0) > 0);
    const totalPackages = itemsToReceive.reduce((sum, item) => sum + (receivedQuantities[item.id] || 0), 0);

    return {
      itemsToReceive: itemsToReceive.length,
      totalPackages,
      totalUnits: totalPackages
    };
  }, [purchaseOrder.items, receivedQuantities]);

  const hasPreAppliedStock = purchaseOrder.items.some(item => item.preAppliedQty > 0);
  const canSubmit = summary.itemsToReceive > 0 && !isSubmitting;

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setError(null);

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      console.log('Recepción confirmada:', receivedQuantities);
      onClose();
    } catch (err) {
      setError('Error al confirmar la recepción. Inténtalo de nuevo.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const allItemsReceived = purchaseOrder.items.every(item => {
    const pending = item.quantityOrdered - item.previouslyReceived - item.preAppliedQty;
    return pending <= 0;
  });

  return (
    <Dialog.Root open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-background z-50" />
        <Dialog.Content className="fixed inset-0 z-50 bg-background flex flex-col">
          <VisuallyHidden.Root>
            <Dialog.Title>Check In - {purchaseOrder.number}</Dialog.Title>
            <Dialog.Description>
              Recepción de mercancía para la orden de compra {purchaseOrder.number} de {purchaseOrder.supplier}
            </Dialog.Description>
          </VisuallyHidden.Root>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border-b border-red-200 dark:border-red-700/50 px-6 py-3 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0" />
              <p className="text-sm text-red-800 dark:text-red-400">{error}</p>
            </div>
          )}

          <div className="sticky top-0 border-b border-border bg-gray-50/50 dark:bg-muted/20 px-6 py-4">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-green-100 dark:bg-green-500/20 flex items-center justify-center">
                  <PackageCheck className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">Check In de Mercancía</h2>
                  <p className="text-sm text-muted-foreground mt-0.5">Recepción de productos</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Número de Orden</p>
                <p className="font-semibold">{purchaseOrder.number}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Proveedor</p>
                <p className="font-semibold">{purchaseOrder.supplier}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Destino</p>
                <p className="font-semibold">{purchaseOrder.location}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Fecha de Emisión</p>
                <p className="font-semibold">{purchaseOrder.issueDate}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Fecha Esperada</p>
                <p className="font-semibold">{purchaseOrder.expectedArrivalDate}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Total Items</p>
                <p className="font-semibold">{purchaseOrder.items.length} productos</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Pendientes</p>
                <p className="font-semibold text-amber-600 dark:text-amber-400">{stats.pending + stats.partial} items</p>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {hasPreAppliedStock && (
              <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-lg p-4 flex gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-800 dark:text-amber-400">
                  <p className="font-medium mb-1">⚠️ Esta OC viene desde POS con stock preaplicado.</p>
                  <p>No volverá a sumar inventario por esa base. Solo se recibirá la diferencia si aumentas cantidades.</p>
                </div>
              </div>
            )}

            <div className="flex justify-end">
              <button
                onClick={handleMassCheckIn}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
              >
                <PackageCheck className="w-4 h-4" />
                Check In Masivo
              </button>
            </div>

            {allItemsReceived ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <PackageCheck className="w-12 h-12 text-green-600 dark:text-green-400 mb-4" />
                <h3 className="text-lg font-medium mb-2">Todos los items ya han sido recibidos</h3>
                <p className="text-sm text-muted-foreground">Esta orden de compra está completa</p>
              </div>
            ) : (
              <>
                <div className="border border-border rounded-lg overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 dark:bg-muted/20 border-b border-border">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground w-20">Estado</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Producto</th>
                          <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground w-24">Pedido</th>
                          <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground w-24">Recibido</th>
                          <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground w-28">Recibir</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {purchaseOrder.items.map(item => {
                          const status = getItemStatus(item);
                          const pending = item.quantityOrdered - item.previouslyReceived - item.preAppliedQty;
                          const isCompleted = pending <= 0;

                          return (
                            <ItemRow
                              key={item.id}
                              item={item}
                              status={status}
                              pending={pending}
                              receivedQty={receivedQuantities[item.id] || 0}
                              isCompleted={isCompleted}
                              onQuantityChange={(value) => handleQuantityChange(item.id, value)}
                            />
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="bg-gray-50 dark:bg-muted/20 rounded-lg p-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Items a recibir:</span>
                    <span className="font-semibold">{summary.itemsToReceive}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Paquetes totales a recibir:</span>
                    <span className="font-semibold">{summary.totalPackages}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Unidades totales a recibir:</span>
                    <span className="font-semibold">{summary.totalUnits} (×1 und/paq)</span>
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="sticky bottom-0 h-16 border-t border-border bg-gray-50/50 dark:bg-muted/20 px-6 flex items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-border bg-card hover:bg-accent transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={handleSubmit}
              disabled={!canSubmit}
              className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Confirmando...
                </>
              ) : (
                `Confirmar Recepción (${summary.itemsToReceive} items)`
              )}
            </button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

interface ItemRowProps {
  item: PurchaseOrderItem;
  status: ItemStatus;
  pending: number;
  receivedQty: number;
  isCompleted: boolean;
  onQuantityChange: (value: string) => void;
}

function ItemRow({ item, status, pending, receivedQty, isCompleted, onQuantityChange }: ItemRowProps) {
  const statusConfig = {
    ok: { label: 'OK', emoji: '🟢', classes: 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' },
    partial: { label: 'Falta', emoji: '🔴', classes: 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400' },
    excess: { label: 'Exc.', emoji: '🟡', classes: 'bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-400' },
    pending: { label: 'Pend.', emoji: '⚪', classes: 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400' }
  };

  const config = statusConfig[status];
  const rowBg = isCompleted ? 'bg-green-50/50 dark:bg-green-900/10' : '';

  return (
    <tr className={rowBg}>
      <td className="px-4 py-3">
        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold ${config.classes}`}>
          <span>{config.emoji}</span>
          <span>{config.label}</span>
        </span>
      </td>
      <td className="px-4 py-3">
        <div>
          <p className="font-medium text-sm">{item.productName}</p>
          <p className="text-xs text-muted-foreground font-mono mt-0.5">{item.sku}</p>
          <span className="inline-block mt-1 px-2 py-0.5 bg-gray-100 dark:bg-gray-800 rounded text-xs text-muted-foreground">
            [{item.brand}]
          </span>
          {item.preAppliedQty > 0 && (
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
              POS: {item.preAppliedQty} {item.unit} preaplicado
            </p>
          )}
        </div>
      </td>
      <td className="px-4 py-3 text-right">
        <div className="text-sm">
          <p className="font-medium">{item.quantityOrdered}</p>
          <p className="text-xs text-muted-foreground">{item.unit}</p>
        </div>
      </td>
      <td className="px-4 py-3 text-right">
        <div className="text-sm">
          <p className="font-medium">{item.previouslyReceived}</p>
          <p className="text-xs text-muted-foreground">{item.unit}</p>
        </div>
      </td>
      <td className="px-4 py-3 text-right">
        {isCompleted ? (
          <span className="text-xs text-muted-foreground">Ya recibido</span>
        ) : (
          <div className="flex justify-end">
            <input
              type="number"
              min="0"
              value={receivedQty}
              onChange={(e) => onQuantityChange(e.target.value)}
              className="w-20 px-2 py-1 text-right border border-border rounded bg-card focus:outline-none focus:ring-2 focus:ring-ring text-sm"
            />
          </div>
        )}
      </td>
    </tr>
  );
}
