import { useState } from 'react';
import { CheckInModal } from './components/CheckInModal';

const mockPurchaseOrder = {
  id: 'po-001',
  number: 'PO-20260426-0001',
  supplier: 'L&J AUTOPARTES LJ',
  location: 'Local Centro - Bogotá',
  issueDate: '26/04/2026',
  expectedArrivalDate: '30/04/2026',
  items: [
    {
      id: '1',
      productName: 'TERMINAL EXTERNO',
      sku: '45046-59026',
      brand: '555',
      quantityOrdered: 5,
      previouslyReceived: 5,
      preAppliedQty: 0,
      unit: 'paq.'
    },
    {
      id: '2',
      productName: 'BASE MOTOR HYUNDAI',
      sku: '22311-4A100-M',
      brand: 'BOSCH',
      quantityOrdered: 3,
      previouslyReceived: 1,
      preAppliedQty: 1,
      unit: 'paq.'
    },
    {
      id: '3',
      productName: 'EMPAQUE CABEZA',
      sku: '22311-4A100-AS',
      brand: 'JIKIU',
      quantityOrdered: 2,
      previouslyReceived: 3,
      preAppliedQty: 0,
      unit: 'paq.'
    },
    {
      id: '4',
      productName: 'BALINERA RUEDA',
      sku: '51720-1W000',
      brand: '555',
      quantityOrdered: 4,
      previouslyReceived: 0,
      preAppliedQty: 0,
      unit: 'paq.'
    },
    {
      id: '5',
      productName: 'ACEITE MOTOR',
      sku: 'ACE-0001',
      brand: 'GENÉRICA',
      quantityOrdered: 10,
      previouslyReceived: 0,
      preAppliedQty: 0,
      unit: 'paq.'
    }
  ]
};

export default function App() {
  const [isModalOpen, setIsModalOpen] = useState(true);

  return (
    <div className="size-full flex items-center justify-center bg-background p-8">
      <div className="text-center space-y-4">
        <h1 className="text-2xl font-bold">HermeX POS - Sistema de Check In</h1>
        <p className="text-muted-foreground">Modal de recepción de mercancía</p>
        <button
          onClick={() => setIsModalOpen(true)}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors"
        >
          Abrir Check In Modal
        </button>
      </div>

      <CheckInModal
        open={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        purchaseOrder={mockPurchaseOrder}
      />
    </div>
  );
}